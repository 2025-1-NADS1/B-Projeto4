﻿using System;
using System.Windows.Forms;

namespace SmartHomeApp
{
    public partial class FormRecompensas : Form
    {
        private int pontos = 300;

        public FormRecompensas()
        {
            InitializeComponent();
            lblPontos.Text = $"Pontos: {pontos}";
        }

        private void btnResgatar_Click(object sender, EventArgs e)
        {
            if (pontos >= 50)
            {
                pontos -= 50;
                MessageBox.Show("Recompensa resgatada com sucesso!");
            }
            else
            {
                MessageBox.Show("Pontos insuficientes!");
            }
            lblPontos.Text = $"Pontos: {pontos}";
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            FormUsuario home = new FormUsuario();
            home.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            FormUsuario homeForm = new FormUsuario();
            homeForm.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            FormMensagens mensagensForm = new FormMensagens();
            mensagensForm.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            FormTarefas tarefasForm = new FormTarefas();
            tarefasForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (pontos >= 50)
            {
                pontos -= 50;
                MessageBox.Show("Recompensa resgatada com sucesso!");
            }
            else
            {
                MessageBox.Show("Pontos insuficientes!");
            }
            lblPontos.Text = $"Pontos: {pontos}";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (pontos >= 50)
            {
                pontos -= 50;
                MessageBox.Show("Recompensa resgatada com sucesso!");
            }
            else
            {
                MessageBox.Show("Pontos insuficientes!");
            }
            lblPontos.Text = $"Pontos: {pontos}";
        }
    }
}
