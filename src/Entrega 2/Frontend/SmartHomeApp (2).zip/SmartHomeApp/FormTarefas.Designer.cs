﻿namespace SmartHomeApp
{
    partial class FormTarefas
    {
        private System.ComponentModel.IContainer components = null;
        private Button btnCompletarTarefa;
        private Label lblPontos;
        private Label lblXP;
        private Label lblNivel;
        private Button btnHome;

        private void InitializeComponent()
        {
            btnCompletarTarefa = new Button();
            lblPontos = new Label();
            lblXP = new Label();
            lblNivel = new Label();
            btnHome = new Button();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // btnCompletarTarefa
            // 
            btnCompletarTarefa.BackColor = Color.Navy;
            btnCompletarTarefa.ForeColor = Color.White;
            btnCompletarTarefa.Location = new Point(117, 95);
            btnCompletarTarefa.Name = "btnCompletarTarefa";
            btnCompletarTarefa.Size = new Size(403, 43);
            btnCompletarTarefa.TabIndex = 0;
            btnCompletarTarefa.Text = "Completar Tarefa";
            btnCompletarTarefa.UseVisualStyleBackColor = false;
            btnCompletarTarefa.Click += btnCompletarTarefa_Click;
            // 
            // lblPontos
            // 
            lblPontos.ForeColor = Color.Navy;
            lblPontos.Location = new Point(800, 67);
            lblPontos.Name = "lblPontos";
            lblPontos.Size = new Size(150, 20);
            lblPontos.TabIndex = 1;
            lblPontos.Text = "Pontos: 0";
            // 
            // lblXP
            // 
            lblXP.ForeColor = Color.Navy;
            lblXP.Location = new Point(800, 47);
            lblXP.Name = "lblXP";
            lblXP.Size = new Size(150, 20);
            lblXP.TabIndex = 2;
            lblXP.Text = "XP: 0 / 100";
            // 
            // lblNivel
            // 
            lblNivel.Font = new Font("Segoe UI", 20F);
            lblNivel.ForeColor = Color.Navy;
            lblNivel.Location = new Point(784, 9);
            lblNivel.Name = "lblNivel";
            lblNivel.Size = new Size(221, 70);
            lblNivel.TabIndex = 3;
            lblNivel.Text = "Nível: 1";
            // 
            // btnHome
            // 
            btnHome.Location = new Point(-4, 522);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(10, 10);
            btnHome.TabIndex = 4;
            btnHome.Text = "🏠";
            btnHome.Click += btnHome_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.NÍVEL_3__8__removebg_preview;
            pictureBox1.Location = new Point(800, 67);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(149, 112);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Navy;
            button1.ForeColor = Color.White;
            button1.Location = new Point(117, 219);
            button1.Name = "button1";
            button1.Size = new Size(403, 43);
            button1.TabIndex = 6;
            button1.Text = "Completar Tarefa";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Navy;
            button2.ForeColor = Color.White;
            button2.Location = new Point(117, 351);
            button2.Name = "button2";
            button2.Size = new Size(403, 43);
            button2.TabIndex = 7;
            button2.Text = "Completar Tarefa";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(94, 62);
            label1.Name = "label1";
            label1.Size = new Size(464, 25);
            label1.TabIndex = 8;
            label1.Text = "Fique 3 meses abaixo do vermelho no controle de luz.";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(94, 191);
            label2.Name = "label2";
            label2.Size = new Size(464, 25);
            label2.TabIndex = 9;
            label2.Text = "Fique 5 meses abaixo do vermelho no controle de luz.";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14F);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(94, 323);
            label3.Name = "label3";
            label3.Size = new Size(477, 25);
            label3.TabIndex = 10;
            label3.Text = "Fique 3 meses abaixo do vermelho no controle de água\r\n";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.NÍVEL_3__1__removebg_preview;
            pictureBox2.Location = new Point(790, 145);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(178, 114);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 11;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.NÍVEL_3__2__removebg_preview1;
            pictureBox4.Location = new Point(802, 223);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(157, 148);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 12;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.NÍVEL_3__5__removebg_preview__1_;
            pictureBox3.Location = new Point(441, 135);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(508, 500);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 13;
            pictureBox3.TabStop = false;
            // 
            // FormTarefas
            // 
            ClientSize = new Size(928, 496);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox2);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(lblPontos);
            Controls.Add(lblXP);
            Controls.Add(pictureBox1);
            Controls.Add(btnCompletarTarefa);
            Controls.Add(lblNivel);
            Controls.Add(btnHome);
            Controls.Add(pictureBox3);
            Name = "FormTarefas";
            Text = "Tarefas";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private PictureBox pictureBox1;
        private Button button1;
        private Button button2;
        private Label label1;
        private Label label2;
        private Label label3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
    }
}
