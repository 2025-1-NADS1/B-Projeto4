﻿using System;
using System.Windows.Forms;

namespace SmartHomeApp
{
    public partial class FormTarefas : Form
    {
        private int pontos = 0;
        private int xp = 0;
        private int nivel = 1;

        public FormTarefas()
        {
            InitializeComponent();
        }

        private void btnCompletarTarefa_Click(object sender, EventArgs e)
        {
            pontos += 10;
            xp += 10;

            if (xp >= 100)
            {
                nivel++;
                xp = 0;
                MessageBox.Show($"Parabéns! Você subiu para o nível {nivel}!");
            }

            lblPontos.Text = $"Pontos: {pontos}";
            lblXP.Text = $"XP: {xp} / 100";
            lblNivel.Text = $"Nível: {nivel}";
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            FormUsuario home = new FormUsuario();
            home.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            FormUsuario home = new FormUsuario();
            home.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            pontos += 10;
            xp += 10;

            if (xp >= 100)
            {
                nivel++;
                xp = 0;
                MessageBox.Show($"Parabéns! Você subiu para o nível {nivel}!");
            }

            lblPontos.Text = $"Pontos: {pontos}";
            lblXP.Text = $"XP: {xp} / 100";
            lblNivel.Text = $"Nível: {nivel}";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pontos += 10;
            xp += 10;

            if (xp >= 100)
            {
                nivel++;
                xp = 0;
                MessageBox.Show($"Parabéns! Você subiu para o nível {nivel}!");
            }

            lblPontos.Text = $"Pontos: {pontos}";
            lblXP.Text = $"XP: {xp} / 100";
            lblNivel.Text = $"Nível: {nivel}";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            FormMensagens mensagensForm = new FormMensagens();
            mensagensForm.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            FormRecompensas recompensasForm = new FormRecompensas();
            recompensasForm.Show();
            this.Hide();
        }
    }
}
