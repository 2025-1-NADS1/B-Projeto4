﻿using System;
using System.Windows.Forms;

namespace SmartHomeApp
{
    public partial class FormMensagens : Form
    {
        public FormMensagens()
        {
            InitializeComponent();
        }

        private void FormMensagens_Load(object sender, EventArgs e)
        {
            listBoxMensagens.Items.Add("Administrador");
            listBoxMensagens.Items.Add("");
            listBoxMensagens.Items.Add("Lembre-se de apagar as luzes ao sair!");
            listBoxMensagens.Items.Add("Economize água ao lavar a louça.");
            listBoxMensagens.Items.Add("Dica do dia: desligue aparelhos que não estão em uso.");
            listBoxMensagens.Items.Add("Por favor não escutar música alta após as 22h00!");
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            FormUsuario home = new FormUsuario();
            home.Show();
            this.Hide();
        }

        private void listBoxMensagens_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
