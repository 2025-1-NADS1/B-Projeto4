﻿namespace SmartHomeApp
{
    partial class FormRecompensas
    {
        private System.ComponentModel.IContainer components = null;
        private Label lblPontos;
        private Button btnResgatar;
        private Button btnHome;

        private void InitializeComponent()
        {
            lblPontos = new Label();
            btnResgatar = new Button();
            btnHome = new Button();
            label1 = new Label();
            lblXP = new Label();
            pictureBox1 = new PictureBox();
            lblNivel = new Label();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            pictureBox4 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // lblPontos
            // 
            lblPontos.Font = new Font("Segoe UI", 20F);
            lblPontos.ForeColor = Color.Navy;
            lblPontos.Location = new Point(30, 9);
            lblPontos.Name = "lblPontos";
            lblPontos.Size = new Size(171, 38);
            lblPontos.TabIndex = 0;
            lblPontos.Text = "Pontos: 0";
            // 
            // btnResgatar
            // 
            btnResgatar.BackColor = Color.Navy;
            btnResgatar.ForeColor = Color.White;
            btnResgatar.Location = new Point(112, 135);
            btnResgatar.Name = "btnResgatar";
            btnResgatar.Size = new Size(415, 38);
            btnResgatar.TabIndex = 1;
            btnResgatar.Text = "Resgatar Recompensa";
            btnResgatar.UseVisualStyleBackColor = false;
            btnResgatar.Click += btnResgatar_Click;
            // 
            // btnHome
            // 
            btnHome.Location = new Point(-4, 523);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(10, 10);
            btnHome.TabIndex = 2;
            btnHome.Text = "🏠";
            btnHome.Click += btnHome_Click;
            // 
            // label1
            // 
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(758, 61);
            label1.Name = "label1";
            label1.Size = new Size(150, 20);
            label1.TabIndex = 6;
            label1.Text = "Pontos: 0";
            // 
            // lblXP
            // 
            lblXP.ForeColor = Color.Navy;
            lblXP.Location = new Point(757, 41);
            lblXP.Name = "lblXP";
            lblXP.Size = new Size(150, 20);
            lblXP.TabIndex = 7;
            lblXP.Text = "XP: 0 / 100";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.NÍVEL_3__8__removebg_preview;
            pictureBox1.Location = new Point(764, 61);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(149, 112);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // lblNivel
            // 
            lblNivel.Font = new Font("Segoe UI", 20F);
            lblNivel.ForeColor = Color.Navy;
            lblNivel.Location = new Point(753, 3);
            lblNivel.Name = "lblNivel";
            lblNivel.Size = new Size(221, 70);
            lblNivel.TabIndex = 8;
            lblNivel.Text = "Nível: 1";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.NÍVEL_3__1__removebg_preview;
            pictureBox2.Location = new Point(753, 145);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(178, 114);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 10;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.NÍVEL_3__4__removebg_preview1;
            pictureBox3.Location = new Point(756, 230);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(175, 119);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 11;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Navy;
            button1.ForeColor = Color.White;
            button1.Location = new Point(112, 262);
            button1.Name = "button1";
            button1.Size = new Size(415, 38);
            button1.TabIndex = 12;
            button1.Text = "Resgatar Recompensa";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Navy;
            button2.ForeColor = Color.White;
            button2.Location = new Point(112, 392);
            button2.Name = "button2";
            button2.Size = new Size(415, 38);
            button2.TabIndex = 13;
            button2.Text = "Resgatar Recompensa";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(99, 98);
            label2.Name = "label2";
            label2.Size = new Size(464, 25);
            label2.TabIndex = 14;
            label2.Text = "Fique 3 meses abaixo do vermelho no controle de luz.";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14F);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(99, 230);
            label3.Name = "label3";
            label3.Size = new Size(464, 25);
            label3.TabIndex = 15;
            label3.Text = "Fique 3 meses abaixo do vermelho no controle de luz.";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14F);
            label4.ForeColor = Color.Navy;
            label4.Location = new Point(99, 364);
            label4.Name = "label4";
            label4.Size = new Size(464, 25);
            label4.TabIndex = 16;
            label4.Text = "Fique 3 meses abaixo do vermelho no controle de luz.";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.NÍVEL_3__9__removebg_preview__1_;
            pictureBox4.Location = new Point(425, 179);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(536, 504);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 17;
            pictureBox4.TabStop = false;
            // 
            // FormRecompensas
            // 
            ClientSize = new Size(896, 533);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(label1);
            Controls.Add(lblXP);
            Controls.Add(pictureBox1);
            Controls.Add(lblNivel);
            Controls.Add(lblPontos);
            Controls.Add(btnResgatar);
            Controls.Add(btnHome);
            Controls.Add(pictureBox4);
            Name = "FormRecompensas";
            Text = "Recompensas";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label1;
        private Label lblXP;
        private PictureBox pictureBox1;
        private Label lblNivel;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private Button button1;
        private Button button2;
        private Label label2;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox4;
    }
}
