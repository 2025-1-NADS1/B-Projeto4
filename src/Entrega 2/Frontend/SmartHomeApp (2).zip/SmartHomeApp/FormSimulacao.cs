﻿using System;
using System.Windows.Forms;

namespace SmartHomeApp
{
    public partial class FormSimulacao : Form
    {
        Random rnd = new Random();

        public FormSimulacao()
        {
            InitializeComponent();
        }

        private void FormSimulacao_Load(object sender, EventArgs e)
        {
            AtualizarSimulacao();
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            AtualizarSimulacao();
        }

        private void AtualizarSimulacao()
        {
            lblLuz.Text = $"Consumo Luz: {rnd.Next(100, 400)} kWh";
            lblAgua.Text = $"Consumo Água: {rnd.Next(50, 200)} litros";
            lblCO2.Text = $"CO2: {rnd.Next(30, 90)} g/m³";
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            FormUsuario home = new FormUsuario();
            home.Show();
            this.Hide();
        }
    }
}
