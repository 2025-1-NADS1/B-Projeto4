﻿using System;
using System.Windows.Forms;

namespace SmartHomeApp
{
    public partial class FormUsuario : Form
    {
        public FormUsuario()
        {
            InitializeComponent();
        }

        private void btnTarefas_Click(object sender, EventArgs e)
        {
            FormTarefas tarefasForm = new FormTarefas();
            tarefasForm.Show();
            this.Hide();
        }

        private void btnRecompensas_Click(object sender, EventArgs e)
        {
            FormRecompensas recompensasForm = new FormRecompensas();
            recompensasForm.Show();
            this.Hide();
        }

        private void btnMensagens_Click(object sender, EventArgs e)
        {
            FormMensagens mensagensForm = new FormMensagens();
            mensagensForm.Show();
            this.Hide();
        }

        private void btnControleSustentavel_Click(object sender, EventArgs e)
        {
            FormControleSustentavel sustentavelForm = new FormControleSustentavel();
            sustentavelForm.Show();
            this.Hide();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            FormUsuario homeForm = new FormUsuario();
            homeForm.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e) // Mensagens Original
        {
            FormMensagens mensagensForm = new FormMensagens();
            mensagensForm.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e) //Tarefas Original
        {
            FormTarefas tarefasForm = new FormTarefas();
            tarefasForm.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e) // Recompensas Original
        {
            FormRecompensas recompensasForm = new FormRecompensas();
            recompensasForm.Show();
            this.Hide();
        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            FormControleSustentavel sustentavelForm = new FormControleSustentavel();
            sustentavelForm.Show();
            this.Hide();
        }

        private void FormUsuario_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Form1 loginForm = new Form1();
            loginForm.Show();
            this.Hide();
        }
    }
}
