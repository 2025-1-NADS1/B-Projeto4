﻿namespace SmartHomeApp
{
    partial class FormUsuario
    {
        private System.ComponentModel.IContainer components = null;
        private Button btnTarefas;
        private Button btnRecompensas;
        private Button btnMensagens;
        private Button btnControleSustentavel;
        private Button btnHome;

        private void InitializeComponent()
        {
            btnTarefas = new Button();
            btnRecompensas = new Button();
            btnMensagens = new Button();
            btnControleSustentavel = new Button();
            btnHome = new Button();
            pictureBox1 = new PictureBox();
            lblNivel = new Label();
            lblXP = new Label();
            lblPontos = new Label();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            SuspendLayout();
            // 
            // btnTarefas
            // 
            btnTarefas.Location = new Point(-4, -2);
            btnTarefas.Name = "btnTarefas";
            btnTarefas.Size = new Size(10, 10);
            btnTarefas.TabIndex = 0;
            btnTarefas.Text = "Tarefas";
            btnTarefas.Click += btnTarefas_Click;
            // 
            // btnRecompensas
            // 
            btnRecompensas.Location = new Point(886, 485);
            btnRecompensas.Name = "btnRecompensas";
            btnRecompensas.Size = new Size(10, 10);
            btnRecompensas.TabIndex = 1;
            btnRecompensas.Text = "Recompensas";
            btnRecompensas.Click += btnRecompensas_Click;
            // 
            // btnMensagens
            // 
            btnMensagens.Location = new Point(886, 501);
            btnMensagens.Name = "btnMensagens";
            btnMensagens.Size = new Size(10, 10);
            btnMensagens.TabIndex = 2;
            btnMensagens.Text = "Mensagens";
            btnMensagens.Click += btnMensagens_Click;
            // 
            // btnControleSustentavel
            // 
            btnControleSustentavel.Location = new Point(-4, 485);
            btnControleSustentavel.Name = "btnControleSustentavel";
            btnControleSustentavel.Size = new Size(10, 10);
            btnControleSustentavel.TabIndex = 3;
            btnControleSustentavel.Text = "Controle Sustentável";
            btnControleSustentavel.Click += btnControleSustentavel_Click;
            // 
            // btnHome
            // 
            btnHome.Location = new Point(-4, 501);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(10, 10);
            btnHome.TabIndex = 4;
            btnHome.Text = "🏠 Home";
            btnHome.Click += btnHome_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.NÍVEL_3__5__removebg_preview;
            pictureBox1.Location = new Point(371, 110);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(548, 558);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // lblNivel
            // 
            lblNivel.Font = new Font("Segoe UI", 20F);
            lblNivel.ForeColor = Color.Navy;
            lblNivel.Location = new Point(760, 9);
            lblNivel.Name = "lblNivel";
            lblNivel.Size = new Size(221, 70);
            lblNivel.TabIndex = 6;
            lblNivel.Text = "Nível: 1";
            // 
            // lblXP
            // 
            lblXP.ForeColor = Color.Navy;
            lblXP.Location = new Point(769, 44);
            lblXP.Name = "lblXP";
            lblXP.Size = new Size(150, 20);
            lblXP.TabIndex = 7;
            lblXP.Text = "XP: 0 / 100";
            // 
            // lblPontos
            // 
            lblPontos.ForeColor = Color.Navy;
            lblPontos.Location = new Point(769, 59);
            lblPontos.Name = "lblPontos";
            lblPontos.Size = new Size(150, 20);
            lblPontos.TabIndex = 8;
            lblPontos.Text = "Pontos: 0";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.NÍVEL_3__1__removebg_preview;
            pictureBox2.Location = new Point(760, 82);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(178, 114);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 9;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.NÍVEL_3__4__removebg_preview1;
            pictureBox3.Location = new Point(763, 162);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(175, 119);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.NÍVEL_3__2__removebg_preview1;
            pictureBox4.Location = new Point(770, 244);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(157, 148);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 11;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(115, 82);
            label1.Name = "label1";
            label1.Size = new Size(109, 28);
            label1.TabIndex = 12;
            label1.Text = "CONTROLE";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(115, 110);
            label2.Name = "label2";
            label2.Size = new Size(135, 28);
            label2.TabIndex = 13;
            label2.Text = "SUSTENTAVEL";
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.NÍVEL_3_removebg_preview_removebg_preview;
            pictureBox5.Location = new Point(163, 49);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(224, 89);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 14;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.LOGIN__59_4_x_42_cm___2__removebg_preview;
            pictureBox6.Location = new Point(767, 346);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(172, 99);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 29;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // FormUsuario
            // 
            ClientSize = new Size(895, 511);
            Controls.Add(pictureBox6);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(lblPontos);
            Controls.Add(lblXP);
            Controls.Add(lblNivel);
            Controls.Add(pictureBox1);
            Controls.Add(btnTarefas);
            Controls.Add(btnRecompensas);
            Controls.Add(btnMensagens);
            Controls.Add(btnControleSustentavel);
            Controls.Add(btnHome);
            Controls.Add(pictureBox5);
            Name = "FormUsuario";
            Text = "Área do Usuário";
            Load += FormUsuario_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private PictureBox pictureBox1;
        private Label lblNivel;
        private Label lblXP;
        private Label lblPontos;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private Label label1;
        private Label label2;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
    }
}
