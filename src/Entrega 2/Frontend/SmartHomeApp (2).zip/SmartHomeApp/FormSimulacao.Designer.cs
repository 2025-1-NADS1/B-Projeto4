﻿namespace SmartHomeApp
{
    partial class FormSimulacao
    {
        private System.ComponentModel.IContainer components = null;
        private Label lblLuz;
        private Label lblAgua;
        private Label lblCO2;
        private Button btnAtualizar;
        private Button btnHome;

        private void InitializeComponent()
        {
            this.lblLuz = new Label();
            this.lblAgua = new Label();
            this.lblCO2 = new Label();
            this.btnAtualizar = new Button();
            this.btnHome = new Button();
            this.SuspendLayout();

            // lblLuz
            this.lblLuz.Location = new System.Drawing.Point(30, 30);
            this.lblLuz.Size = new System.Drawing.Size(250, 20);

            // lblAgua
            this.lblAgua.Location = new System.Drawing.Point(30, 60);
            this.lblAgua.Size = new System.Drawing.Size(250, 20);

            // lblCO2
            this.lblCO2.Location = new System.Drawing.Point(30, 90);
            this.lblCO2.Size = new System.Drawing.Size(250, 20);

            // btnAtualizar
            this.btnAtualizar.Location = new System.Drawing.Point(30, 130);
            this.btnAtualizar.Size = new System.Drawing.Size(120, 30);
            this.btnAtualizar.Text = "🔄 Atualizar";
            this.btnAtualizar.Click += new System.EventHandler(this.btnAtualizar_Click);

            // btnHome
            this.btnHome.Location = new System.Drawing.Point(180, 130);
            this.btnHome.Size = new System.Drawing.Size(75, 30);
            this.btnHome.Text = "🏠";
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);

            // FormSimulacao
            this.ClientSize = new System.Drawing.Size(340, 190);
            this.Controls.Add(this.lblLuz);
            this.Controls.Add(this.lblAgua);
            this.Controls.Add(this.lblCO2);
            this.Controls.Add(this.btnAtualizar);
            this.Controls.Add(this.btnHome);
            this.Name = "FormSimulacao";
            this.Text = "Simulação de Consumo";
            this.Load += new System.EventHandler(this.FormSimulacao_Load);
            this.ResumeLayout(false);
        }
    }
}
