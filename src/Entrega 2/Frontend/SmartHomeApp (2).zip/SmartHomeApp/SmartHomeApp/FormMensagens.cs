﻿using System;
using System.Windows.Forms;

namespace SmartHomeApp
{
    public partial class FormMensagens : Form
    {
        public FormMensagens()
        {
            InitializeComponent();
        }

        private void FormMensagens_Load(object sender, EventArgs e)
        {
            listBoxMensagens.Items.Add("Administrador");

            listBoxMensagens.Items.Add("Lembre-se de apagar as luzes ao sair!");
            listBoxMensagens.Items.Add("Economize água ao lavar a louça.");
            listBoxMensagens.Items.Add("Dica do dia: desligue aparelhos em stand-by.");
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            FormUsuario home = new FormUsuario();
            home.Show();
            this.Hide();
        }

        private void listBoxMensagens_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            FormUsuario form = new FormUsuario();
            form.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            FormTarefas form = new FormTarefas();
            form.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            FormRecompensas form = new FormRecompensas();
            form.Show();
            this.Hide();
        }
    }
}
