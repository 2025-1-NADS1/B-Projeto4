﻿namespace SmartHomeApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnLogin;
        private Button btnSustentavel;

        private void InitializeComponent()
        {
            txtUsername = new TextBox();
            txtPassword = new TextBox();
            btnLogin = new Button();
            btnSustentavel = new Button();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox2 = new PictureBox();
            linkLabel1 = new LinkLabel();
            label2 = new Label();
            btnEnterInvisible = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // txtUsername
            // 
            txtUsername.Font = new Font("Segoe UI", 10F);
            txtUsername.ForeColor = Color.Navy;
            txtUsername.Location = new Point(262, 283);
            txtUsername.Name = "txtUsername";
            txtUsername.PlaceholderText = "Usuário";
            txtUsername.Size = new Size(381, 25);
            txtUsername.TabIndex = 0;
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.White;
            txtPassword.Font = new Font("Segoe UI", 10F);
            txtPassword.ForeColor = Color.Navy;
            txtPassword.Location = new Point(262, 319);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.PlaceholderText = "Senha";
            txtPassword.Size = new Size(381, 25);
            txtPassword.TabIndex = 1;
            txtPassword.TextChanged += txtPassword_TextChanged;
            // 
            // btnLogin
            // 
            btnLogin.Location = new Point(875, 515);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(10, 10);
            btnLogin.TabIndex = 2;
            btnLogin.Text = "Entrar";
            btnLogin.Click += btnLogin_Click;
            // 
            // btnSustentavel
            // 
            btnSustentavel.Location = new Point(-1, 515);
            btnSustentavel.Name = "btnSustentavel";
            btnSustentavel.Size = new Size(10, 10);
            btnSustentavel.TabIndex = 3;
            btnSustentavel.Text = "➡️";
            btnSustentavel.Click += btnSustentavel_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.images;
            pictureBox1.Location = new Point(274, 89);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(344, 150);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 18F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(145, 81);
            label1.Name = "label1";
            label1.Size = new Size(82, 32);
            label1.TabIndex = 6;
            label1.Text = "LOGIN";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.LOGIN__59_4_x_42_cm___4_;
            pictureBox3.Location = new Point(-239, 223);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(651, 401);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 8;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.LOGIN__59_4_x_42_cm___4_;
            pictureBox4.Location = new Point(558, 232);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(572, 359);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 9;
            pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.LOGIN__59_4_x_42_cm___6_;
            pictureBox2.Location = new Point(276, 236);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(323, 282);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 10;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click_2;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.LinkColor = Color.Navy;
            linkLabel1.Location = new Point(468, 406);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(69, 15);
            linkLabel1.TabIndex = 11;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Cadastre-se";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(367, 406);
            label2.Name = "label2";
            label2.Size = new Size(104, 15);
            label2.TabIndex = 12;
            label2.Text = "Não possui conta?";
            // 
            // btnEnterInvisible
            // 
            btnEnterInvisible.Location = new Point(418, 364);
            btnEnterInvisible.Name = "btnEnterInvisible";
            btnEnterInvisible.Size = new Size(75, 23);
            btnEnterInvisible.TabIndex = 13;
            btnEnterInvisible.Text = "button1";
            btnEnterInvisible.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            BackColor = Color.White;
            ClientSize = new Size(886, 526);
            Controls.Add(label2);
            Controls.Add(linkLabel1);
            Controls.Add(txtUsername);
            Controls.Add(txtPassword);
            Controls.Add(pictureBox1);
            Controls.Add(btnLogin);
            Controls.Add(btnSustentavel);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(btnEnterInvisible);
            Name = "Form1";
            Text = "Login";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private PictureBox pictureBox1;
        private Label label1;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox2;
        private LinkLabel linkLabel1;
        private Label label2;
        private Button btnEnterInvisible;
    }
}
