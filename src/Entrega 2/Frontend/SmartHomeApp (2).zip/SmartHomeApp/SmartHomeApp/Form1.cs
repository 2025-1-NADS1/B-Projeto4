using System;
using System.Windows.Forms;
using System.Media; // Para tocar �udio .wav

namespace SmartHomeApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
                this.AcceptButton = btnEnterInvisible;
        }

        private void btnEnterInvisible_Click(object sender, EventArgs e)

        { 
            if (txtUsername.Text == "admin" && txtPassword.Text == "admin")
            {
                FormAdmin adminForm = new FormAdmin();
                adminForm.Show();
                this.Hide();
            }
            else if (txtUsername.Text == "usuario" && txtPassword.Text == "usuario")
            {
                FormUsuario userForm = new FormUsuario();
                userForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Usu�rio ou senha incorretos!");
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "admin" && txtPassword.Text == "admin")
            {
                FormAdmin adminForm = new FormAdmin();
                adminForm.Show();
                this.Hide();
            }
            else if (txtUsername.Text == "usuario" && txtPassword.Text == "usuario")
            {
                FormUsuario userForm = new FormUsuario();
                userForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Usu�rio ou senha incorretos!");
            }
        }

        private void btnSustentavel_Click(object sender, EventArgs e)
        {
         
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            if (txtUsername.Text == "admin" && txtPassword.Text == "admin")
            {
                FormAdmin adminForm = new FormAdmin();
                adminForm.Show();
                this.Hide();
            }
            else if (txtUsername.Text == "usuario" && txtPassword.Text == "usuario")
            {
                FormUsuario userForm = new FormUsuario();
                userForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Usu�rio ou senha incorretos!");
            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click_2(object sender, EventArgs e)
        {
            if (txtUsername.Text == "admin" && txtPassword.Text == "admin")
            {
                FormAdmin adminForm = new FormAdmin();
                adminForm.Show();
                this.Hide();
            }
            else if (txtUsername.Text == "usuario" && txtPassword.Text == "usuario")
            {
                FormUsuario userForm = new FormUsuario();
                userForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Usu�rio ou senha incorretos!");
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormCadastro userForm = new FormCadastro();
            userForm.Show();
            this.Hide();
        }
    }


}
