﻿using System;
using System.Windows.Forms;

namespace SmartHomeApp
{
    public partial class FormSimulacao : Form
    {
        Random rnd = new Random();

        public FormSimulacao()
        {
            InitializeComponent();
        }

        private void FormSimulacao_Load(object sender, EventArgs e)
        {
            AtualizarSimulacao();
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            AtualizarSimulacao();
        }

        private void AtualizarSimulacao()
        {
            // Você pode implementar aqui atualizações visuais com dados aleatórios, se quiser.
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            FormUsuario home = new FormUsuario();
            home.Show();
            this.Hide();
        }

        // 🔹 Função que calcula o volume de água em litros
        private double CalcularLitros(double valorAgua)
        {
            return (valorAgua / 5) * 1000;
        }

        // 🔹 Função que calcula o total de energia em quilowatts
        private double CalcularQuilowatts(double valorLuz)
        {
            return valorLuz * 0.60;
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            double agua = double.Parse(textBox1.Text);
            double luz = double.Parse(textBox2.Text);

            double volume = CalcularLitros(agua);
            double totalLuz = CalcularQuilowatts(luz);

            if (agua >= 200 && luz >= 200)
            {
                label7.Text = "Evite banhos demorados e sempre apague as luzes quando sair do cômodo! Vamos se atentar e economizar!";
            }
            else if (agua >= 150 && luz >= 150)
            {
                label7.Text = "Evite banhos demorados e sempre apague as luzes quando sair do cômodo!";
            }
            else if (agua <= 100 && luz <= 100)
            {
                label7.Text = "Ótimos números, você soube economizar esse mês!";
            }
            else
            {
                label7.Text = "Consumo dentro dos padrões.";
            }

            agualbl.Text = "O valor total em Litros foi: " + volume + " L";
            luzlbl.Text = "O valor total em Quilowatts foi: " + totalLuz + " KwH";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            FormUsuario homeForm = new FormUsuario();
            homeForm.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            FormMensagens mensagensForm = new FormMensagens();
            mensagensForm.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            FormTarefas tarefasForm = new FormTarefas();
            tarefasForm.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            FormRecompensas recompensasForm = new FormRecompensas();
            recompensasForm.Show();
            this.Hide();
        }
    }
}
