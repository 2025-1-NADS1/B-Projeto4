﻿namespace SmartHomeApp
{
    partial class FormCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label1 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            label2 = new Label();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            pictureBox1 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 12F);
            textBox1.ForeColor = Color.Navy;
            textBox1.Location = new Point(36, 34);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Nome do Responsavel";
            textBox1.Size = new Size(473, 29);
            textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 12F);
            textBox2.ForeColor = Color.Navy;
            textBox2.Location = new Point(36, 73);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Nome dos Moradores";
            textBox2.Size = new Size(473, 29);
            textBox2.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(89, 117);
            label1.Name = "label1";
            label1.Size = new Size(336, 21);
            label1.TabIndex = 2;
            label1.Text = "Possui algum tipo de pet? Ex: Cachorro ou Gato";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.BackColor = Color.Transparent;
            radioButton1.Font = new Font("Segoe UI", 12F);
            radioButton1.ForeColor = Color.Navy;
            radioButton1.Location = new Point(205, 141);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(55, 25);
            radioButton1.TabIndex = 3;
            radioButton1.TabStop = true;
            radioButton1.Text = "Sim";
            radioButton1.UseVisualStyleBackColor = false;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Font = new Font("Segoe UI", 12F);
            radioButton2.ForeColor = Color.Navy;
            radioButton2.Location = new Point(266, 141);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(57, 25);
            radioButton2.TabIndex = 4;
            radioButton2.TabStop = true;
            radioButton2.Text = "Não";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Font = new Font("Segoe UI", 12F);
            radioButton3.ForeColor = Color.Navy;
            radioButton3.Location = new Point(263, 194);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(57, 25);
            radioButton3.TabIndex = 7;
            radioButton3.TabStop = true;
            radioButton3.Text = "Não";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Font = new Font("Segoe UI", 12F);
            radioButton4.ForeColor = Color.Navy;
            radioButton4.Location = new Point(203, 194);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(55, 25);
            radioButton4.TabIndex = 6;
            radioButton4.TabStop = true;
            radioButton4.Text = "Sim";
            radioButton4.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(156, 170);
            label2.Name = "label2";
            label2.Size = new Size(211, 21);
            label2.TabIndex = 5;
            label2.Text = "Possui algum residente PCD?";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI", 12F);
            textBox3.ForeColor = Color.Navy;
            textBox3.Location = new Point(36, 225);
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = "Nome de Usuario";
            textBox3.Size = new Size(473, 29);
            textBox3.TabIndex = 8;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Segoe UI", 12F);
            textBox4.ForeColor = Color.Navy;
            textBox4.Location = new Point(36, 269);
            textBox4.Name = "textBox4";
            textBox4.PasswordChar = '*';
            textBox4.PlaceholderText = "Crie uma senha";
            textBox4.Size = new Size(473, 29);
            textBox4.TabIndex = 9;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Segoe UI", 12F);
            textBox5.ForeColor = Color.Navy;
            textBox5.Location = new Point(36, 304);
            textBox5.Name = "textBox5";
            textBox5.PasswordChar = '*';
            textBox5.PlaceholderText = "Confirme a  senha";
            textBox5.Size = new Size(473, 29);
            textBox5.TabIndex = 10;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.NÍVEL_3__5__removebg_preview;
            pictureBox1.Location = new Point(409, 73);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(548, 558);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.LOGIN__59_4_x_42_cm___2__removebg_preview;
            pictureBox6.Location = new Point(765, 3);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(172, 99);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 30;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.LOGIN__59_4_x_42_cm___1_;
            pictureBox2.Location = new Point(15, 237);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(483, 266);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 31;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // FormCadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(896, 472);
            Controls.Add(pictureBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(radioButton3);
            Controls.Add(radioButton4);
            Controls.Add(label2);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox2);
            Name = "FormCadastro";
            Text = "FormCadastro";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private TextBox textBox2;
        private Label label1;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private RadioButton radioButton4;
        private Label label2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private PictureBox pictureBox1;
        private PictureBox pictureBox6;
        private PictureBox pictureBox2;
    }
}