﻿namespace SmartHomeApp
{
    partial class FormMensagens
    {
        private System.ComponentModel.IContainer components = null;
        private ListBox listBoxMensagens;
        private Button btnHome;

        private void InitializeComponent()
        {
            listBoxMensagens = new ListBox();
            btnHome = new Button();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // listBoxMensagens
            // 
            listBoxMensagens.BackColor = Color.White;
            listBoxMensagens.Font = new Font("Segoe UI", 15F);
            listBoxMensagens.ForeColor = Color.Navy;
            listBoxMensagens.ItemHeight = 28;
            listBoxMensagens.Location = new Point(-3, 61);
            listBoxMensagens.Name = "listBoxMensagens";
            listBoxMensagens.Size = new Size(881, 424);
            listBoxMensagens.TabIndex = 0;
            listBoxMensagens.SelectedIndexChanged += listBoxMensagens_SelectedIndexChanged;
            // 
            // btnHome
            // 
            btnHome.Location = new Point(-3, 475);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(10, 10);
            btnHome.TabIndex = 1;
            btnHome.Text = "🏠";
            btnHome.Click += btnHome_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Navy;
            label1.Font = new Font("Segoe UI", 22F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(16, 9);
            label1.Name = "label1";
            label1.Size = new Size(253, 41);
            label1.TabIndex = 2;
            label1.Text = "CHAT DO PREDIO";
            label1.Click += label1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.White;
            pictureBox1.Image = Properties.Resources.NÍVEL_3__7__removebg_preview;
            pictureBox1.Location = new Point(369, 163);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(496, 406);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.White;
            pictureBox2.Image = Properties.Resources.NÍVEL_3__8__removebg_preview;
            pictureBox2.Location = new Point(756, 61);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(149, 112);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 10;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.White;
            pictureBox3.Image = Properties.Resources.NÍVEL_3__4__removebg_preview1;
            pictureBox3.Location = new Point(744, 142);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(175, 119);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 12;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.White;
            pictureBox4.Image = Properties.Resources.NÍVEL_3__2__removebg_preview1;
            pictureBox4.Location = new Point(753, 226);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(157, 148);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 13;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // FormMensagens
            // 
            BackColor = Color.Navy;
            ClientSize = new Size(875, 481);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(listBoxMensagens);
            Controls.Add(btnHome);
            Name = "FormMensagens";
            Text = "Mensagens";
            Load += FormMensagens_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
    }
}
