﻿namespace SmartHomeApp
{
    partial class FormUsuario
    {
        private System.ComponentModel.IContainer components = null;
        private Button btnTarefas;
        private Button btnRecompensas;
        private Button btnMensagens;
        private Button btnControleSustentavel;
        private Button btnHome;

        private void InitializeComponent()
        {
            btnTarefas = new Button();
            btnRecompensas = new Button();
            btnMensagens = new Button();
            btnControleSustentavel = new Button();
            btnHome = new Button();
            pictureBox1 = new PictureBox();
            lblNivel = new Label();
            lblXP = new Label();
            lblPontos = new Label();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            pictureBox6 = new PictureBox();
            label3 = new Label();
            label4 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            radioButton5 = new RadioButton();
            radioButton6 = new RadioButton();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            radioButton7 = new RadioButton();
            radioButton8 = new RadioButton();
            radioButton9 = new RadioButton();
            radioButton10 = new RadioButton();
            radioButton11 = new RadioButton();
            radioButton12 = new RadioButton();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            radioButton13 = new RadioButton();
            radioButton14 = new RadioButton();
            radioButton15 = new RadioButton();
            radioButton16 = new RadioButton();
            label16 = new Label();
            label15 = new Label();
            radioButton17 = new RadioButton();
            radioButton18 = new RadioButton();
            label17 = new Label();
            label18 = new Label();
            radioButton19 = new RadioButton();
            radioButton20 = new RadioButton();
            radioButton21 = new RadioButton();
            radioButton22 = new RadioButton();
            label20 = new Label();
            label19 = new Label();
            radioButton23 = new RadioButton();
            radioButton24 = new RadioButton();
            label22 = new Label();
            pictureBox5 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // btnTarefas
            // 
            btnTarefas.Location = new Point(-4, -2);
            btnTarefas.Name = "btnTarefas";
            btnTarefas.Size = new Size(10, 10);
            btnTarefas.TabIndex = 0;
            btnTarefas.Text = "Tarefas";
            btnTarefas.Click += btnTarefas_Click;
            // 
            // btnRecompensas
            // 
            btnRecompensas.Location = new Point(886, 485);
            btnRecompensas.Name = "btnRecompensas";
            btnRecompensas.Size = new Size(10, 10);
            btnRecompensas.TabIndex = 1;
            btnRecompensas.Text = "Recompensas";
            btnRecompensas.Click += btnRecompensas_Click;
            // 
            // btnMensagens
            // 
            btnMensagens.Location = new Point(886, 501);
            btnMensagens.Name = "btnMensagens";
            btnMensagens.Size = new Size(10, 10);
            btnMensagens.TabIndex = 2;
            btnMensagens.Text = "Mensagens";
            btnMensagens.Click += btnMensagens_Click;
            // 
            // btnControleSustentavel
            // 
            btnControleSustentavel.Location = new Point(-4, 485);
            btnControleSustentavel.Name = "btnControleSustentavel";
            btnControleSustentavel.Size = new Size(10, 10);
            btnControleSustentavel.TabIndex = 3;
            btnControleSustentavel.Text = "Controle Sustentável";
            btnControleSustentavel.Click += btnControleSustentavel_Click;
            // 
            // btnHome
            // 
            btnHome.Location = new Point(-4, 501);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(10, 10);
            btnHome.TabIndex = 4;
            btnHome.Text = "🏠 Home";
            btnHome.Click += btnHome_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.NÍVEL_3__5__removebg_preview;
            pictureBox1.Location = new Point(371, 146);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(548, 558);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // lblNivel
            // 
            lblNivel.Font = new Font("Segoe UI", 20F);
            lblNivel.ForeColor = Color.Navy;
            lblNivel.Location = new Point(760, 9);
            lblNivel.Name = "lblNivel";
            lblNivel.Size = new Size(221, 70);
            lblNivel.TabIndex = 6;
            lblNivel.Text = "Nível: 1";
            // 
            // lblXP
            // 
            lblXP.ForeColor = Color.Navy;
            lblXP.Location = new Point(769, 44);
            lblXP.Name = "lblXP";
            lblXP.Size = new Size(150, 20);
            lblXP.TabIndex = 7;
            lblXP.Text = "XP: 0 / 100";
            // 
            // lblPontos
            // 
            lblPontos.ForeColor = Color.Navy;
            lblPontos.Location = new Point(769, 59);
            lblPontos.Name = "lblPontos";
            lblPontos.Size = new Size(150, 20);
            lblPontos.TabIndex = 8;
            lblPontos.Text = "Pontos: 0";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.NÍVEL_3__1__removebg_preview;
            pictureBox2.Location = new Point(760, 82);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(178, 114);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 9;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.NÍVEL_3__4__removebg_preview1;
            pictureBox3.Location = new Point(763, 162);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(175, 119);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.NÍVEL_3__2__removebg_preview1;
            pictureBox4.Location = new Point(770, 244);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(157, 148);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 11;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(341, 255);
            label1.Name = "label1";
            label1.Size = new Size(109, 28);
            label1.TabIndex = 12;
            label1.Text = "CONTROLE";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(342, 283);
            label2.Name = "label2";
            label2.Size = new Size(135, 28);
            label2.TabIndex = 13;
            label2.Text = "SUSTENTAVEL";
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.LOGIN__59_4_x_42_cm___2__removebg_preview;
            pictureBox6.Location = new Point(767, 346);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(172, 99);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 29;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15F);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(43, 32);
            label3.Name = "label3";
            label3.Size = new Size(123, 28);
            label3.TabIndex = 30;
            label3.Text = "QUARTO DO";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 15F);
            label4.ForeColor = Color.Navy;
            label4.Location = new Point(43, 57);
            label4.Name = "label4";
            label4.Size = new Size(70, 28);
            label4.TabIndex = 31;
            label4.Text = "CASAL";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.ForeColor = Color.Navy;
            radioButton1.Location = new Point(78, 89);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(51, 19);
            radioButton1.TabIndex = 33;
            radioButton1.TabStop = true;
            radioButton1.Text = "Ligar";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.ForeColor = Color.Navy;
            radioButton2.Location = new Point(130, 90);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(67, 19);
            radioButton2.TabIndex = 34;
            radioButton2.TabStop = true;
            radioButton2.Text = "Desligar";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.ForeColor = Color.Navy;
            radioButton3.Location = new Point(195, 109);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(67, 19);
            radioButton3.TabIndex = 36;
            radioButton3.TabStop = true;
            radioButton3.Text = "Desligar";
            radioButton3.UseVisualStyleBackColor = true;
            radioButton3.CheckedChanged += radioButton3_CheckedChanged;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.ForeColor = Color.Navy;
            radioButton4.Location = new Point(144, 108);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(51, 19);
            radioButton4.TabIndex = 35;
            radioButton4.TabStop = true;
            radioButton4.Text = "Ligar";
            radioButton4.UseVisualStyleBackColor = true;
            radioButton4.CheckedChanged += radioButton4_CheckedChanged;
            // 
            // radioButton5
            // 
            radioButton5.AutoSize = true;
            radioButton5.ForeColor = Color.Navy;
            radioButton5.Location = new Point(146, 128);
            radioButton5.Name = "radioButton5";
            radioButton5.Size = new Size(81, 19);
            radioButton5.TabIndex = 38;
            radioButton5.TabStop = true;
            radioButton5.Text = "Destrancar";
            radioButton5.UseVisualStyleBackColor = true;
            radioButton5.CheckedChanged += radioButton5_CheckedChanged;
            // 
            // radioButton6
            // 
            radioButton6.AutoSize = true;
            radioButton6.ForeColor = Color.Navy;
            radioButton6.Location = new Point(83, 127);
            radioButton6.Name = "radioButton6";
            radioButton6.Size = new Size(63, 19);
            radioButton6.TabIndex = 37;
            radioButton6.TabStop = true;
            radioButton6.Text = "Trancar";
            radioButton6.UseVisualStyleBackColor = true;
            radioButton6.CheckedChanged += radioButton6_CheckedChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = Color.Navy;
            label5.Location = new Point(42, 90);
            label5.Name = "label5";
            label5.Size = new Size(28, 15);
            label5.TabIndex = 39;
            label5.Text = " Luz";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.Navy;
            label6.Location = new Point(43, 109);
            label6.Name = "label6";
            label6.Size = new Size(100, 15);
            label6.TabIndex = 40;
            label6.Text = " Ar-condicionado";
            label6.Click += label6_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.ForeColor = Color.Navy;
            label7.Location = new Point(46, 128);
            label7.Name = "label7";
            label7.Size = new Size(35, 15);
            label7.TabIndex = 41;
            label7.Text = "Porta";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.ForeColor = Color.Navy;
            label8.Location = new Point(46, 271);
            label8.Name = "label8";
            label8.Size = new Size(35, 15);
            label8.TabIndex = 53;
            label8.Text = "Porta";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.ForeColor = Color.Navy;
            label9.Location = new Point(43, 252);
            label9.Name = "label9";
            label9.Size = new Size(100, 15);
            label9.TabIndex = 52;
            label9.Text = " Ar-condicionado";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = Color.Navy;
            label10.Location = new Point(42, 233);
            label10.Name = "label10";
            label10.Size = new Size(28, 15);
            label10.TabIndex = 51;
            label10.Text = " Luz";
            // 
            // radioButton7
            // 
            radioButton7.AutoSize = true;
            radioButton7.ForeColor = Color.Navy;
            radioButton7.Location = new Point(146, 271);
            radioButton7.Name = "radioButton7";
            radioButton7.Size = new Size(81, 19);
            radioButton7.TabIndex = 50;
            radioButton7.TabStop = true;
            radioButton7.Text = "Destrancar";
            radioButton7.UseVisualStyleBackColor = true;
            radioButton7.CheckedChanged += radioButton7_CheckedChanged;
            // 
            // radioButton8
            // 
            radioButton8.AutoSize = true;
            radioButton8.ForeColor = Color.Navy;
            radioButton8.Location = new Point(83, 270);
            radioButton8.Name = "radioButton8";
            radioButton8.Size = new Size(63, 19);
            radioButton8.TabIndex = 49;
            radioButton8.TabStop = true;
            radioButton8.Text = "Trancar";
            radioButton8.UseVisualStyleBackColor = true;
            radioButton8.CheckedChanged += radioButton8_CheckedChanged;
            // 
            // radioButton9
            // 
            radioButton9.AutoSize = true;
            radioButton9.ForeColor = Color.Navy;
            radioButton9.Location = new Point(195, 252);
            radioButton9.Name = "radioButton9";
            radioButton9.Size = new Size(67, 19);
            radioButton9.TabIndex = 48;
            radioButton9.TabStop = true;
            radioButton9.Text = "Desligar";
            radioButton9.UseVisualStyleBackColor = true;
            radioButton9.CheckedChanged += radioButton9_CheckedChanged;
            // 
            // radioButton10
            // 
            radioButton10.AutoSize = true;
            radioButton10.ForeColor = Color.Navy;
            radioButton10.Location = new Point(144, 251);
            radioButton10.Name = "radioButton10";
            radioButton10.Size = new Size(51, 19);
            radioButton10.TabIndex = 47;
            radioButton10.TabStop = true;
            radioButton10.Text = "Ligar";
            radioButton10.UseVisualStyleBackColor = true;
            radioButton10.CheckedChanged += radioButton10_CheckedChanged;
            // 
            // radioButton11
            // 
            radioButton11.AutoSize = true;
            radioButton11.ForeColor = Color.Navy;
            radioButton11.Location = new Point(130, 233);
            radioButton11.Name = "radioButton11";
            radioButton11.Size = new Size(67, 19);
            radioButton11.TabIndex = 46;
            radioButton11.TabStop = true;
            radioButton11.Text = "Desligar";
            radioButton11.UseVisualStyleBackColor = true;
            radioButton11.CheckedChanged += radioButton11_CheckedChanged;
            // 
            // radioButton12
            // 
            radioButton12.AutoSize = true;
            radioButton12.ForeColor = Color.Navy;
            radioButton12.Location = new Point(78, 232);
            radioButton12.Name = "radioButton12";
            radioButton12.Size = new Size(51, 19);
            radioButton12.TabIndex = 45;
            radioButton12.TabStop = true;
            radioButton12.Text = "Ligar";
            radioButton12.UseVisualStyleBackColor = true;
            radioButton12.CheckedChanged += radioButton12_CheckedChanged;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 15F);
            label11.ForeColor = Color.Navy;
            label11.Location = new Point(43, 200);
            label11.Name = "label11";
            label11.Size = new Size(94, 28);
            label11.TabIndex = 43;
            label11.Text = "CRIANÇA";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 15F);
            label12.ForeColor = Color.Navy;
            label12.Location = new Point(43, 175);
            label12.Name = "label12";
            label12.Size = new Size(121, 28);
            label12.TabIndex = 42;
            label12.Text = "QUARTO DA";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.ForeColor = Color.Navy;
            label13.Location = new Point(329, 87);
            label13.Name = "label13";
            label13.Size = new Size(100, 15);
            label13.TabIndex = 62;
            label13.Text = " Ar-condicionado";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.ForeColor = Color.Navy;
            label14.Location = new Point(329, 66);
            label14.Name = "label14";
            label14.Size = new Size(28, 15);
            label14.TabIndex = 61;
            label14.Text = " Luz";
            // 
            // radioButton13
            // 
            radioButton13.AutoSize = true;
            radioButton13.ForeColor = Color.Navy;
            radioButton13.Location = new Point(482, 87);
            radioButton13.Name = "radioButton13";
            radioButton13.Size = new Size(67, 19);
            radioButton13.TabIndex = 60;
            radioButton13.TabStop = true;
            radioButton13.Text = "Desligar";
            radioButton13.UseVisualStyleBackColor = true;
            radioButton13.CheckedChanged += radioButton13_CheckedChanged;
            // 
            // radioButton14
            // 
            radioButton14.AutoSize = true;
            radioButton14.ForeColor = Color.Navy;
            radioButton14.Location = new Point(431, 86);
            radioButton14.Name = "radioButton14";
            radioButton14.Size = new Size(51, 19);
            radioButton14.TabIndex = 59;
            radioButton14.TabStop = true;
            radioButton14.Text = "Ligar";
            radioButton14.UseVisualStyleBackColor = true;
            radioButton14.CheckedChanged += radioButton14_CheckedChanged;
            // 
            // radioButton15
            // 
            radioButton15.AutoSize = true;
            radioButton15.ForeColor = Color.Navy;
            radioButton15.Location = new Point(418, 66);
            radioButton15.Name = "radioButton15";
            radioButton15.Size = new Size(67, 19);
            radioButton15.TabIndex = 58;
            radioButton15.TabStop = true;
            radioButton15.Text = "Desligar";
            radioButton15.UseVisualStyleBackColor = true;
            radioButton15.CheckedChanged += radioButton15_CheckedChanged;
            // 
            // radioButton16
            // 
            radioButton16.AutoSize = true;
            radioButton16.ForeColor = Color.Navy;
            radioButton16.Location = new Point(365, 65);
            radioButton16.Name = "radioButton16";
            radioButton16.Size = new Size(51, 19);
            radioButton16.TabIndex = 57;
            radioButton16.TabStop = true;
            radioButton16.Text = "Ligar";
            radioButton16.UseVisualStyleBackColor = true;
            radioButton16.CheckedChanged += radioButton16_CheckedChanged;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI", 15F);
            label16.ForeColor = Color.Navy;
            label16.Location = new Point(330, 32);
            label16.Name = "label16";
            label16.Size = new Size(148, 28);
            label16.TabIndex = 54;
            label16.Text = "SALA DE ESTAR";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.ForeColor = Color.Navy;
            label15.Location = new Point(334, 106);
            label15.Name = "label15";
            label15.Size = new Size(35, 15);
            label15.TabIndex = 65;
            label15.Text = "Porta";
            // 
            // radioButton17
            // 
            radioButton17.AutoSize = true;
            radioButton17.ForeColor = Color.Navy;
            radioButton17.Location = new Point(434, 106);
            radioButton17.Name = "radioButton17";
            radioButton17.Size = new Size(81, 19);
            radioButton17.TabIndex = 64;
            radioButton17.TabStop = true;
            radioButton17.Text = "Destrancar";
            radioButton17.UseVisualStyleBackColor = true;
            radioButton17.CheckedChanged += radioButton17_CheckedChanged;
            // 
            // radioButton18
            // 
            radioButton18.AutoSize = true;
            radioButton18.ForeColor = Color.Navy;
            radioButton18.Location = new Point(371, 105);
            radioButton18.Name = "radioButton18";
            radioButton18.Size = new Size(63, 19);
            radioButton18.TabIndex = 63;
            radioButton18.TabStop = true;
            radioButton18.Text = "Trancar";
            radioButton18.UseVisualStyleBackColor = true;
            radioButton18.CheckedChanged += radioButton18_CheckedChanged;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.ForeColor = Color.Navy;
            label17.Location = new Point(339, 203);
            label17.Name = "label17";
            label17.Size = new Size(100, 15);
            label17.TabIndex = 74;
            label17.Text = " Ar-condicionado";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.ForeColor = Color.Navy;
            label18.Location = new Point(338, 185);
            label18.Name = "label18";
            label18.Size = new Size(28, 15);
            label18.TabIndex = 73;
            label18.Text = " Luz";
            // 
            // radioButton19
            // 
            radioButton19.AutoSize = true;
            radioButton19.ForeColor = Color.Navy;
            radioButton19.Location = new Point(491, 203);
            radioButton19.Name = "radioButton19";
            radioButton19.Size = new Size(67, 19);
            radioButton19.TabIndex = 72;
            radioButton19.TabStop = true;
            radioButton19.Text = "Desligar";
            radioButton19.UseVisualStyleBackColor = true;
            radioButton19.CheckedChanged += radioButton19_CheckedChanged;
            // 
            // radioButton20
            // 
            radioButton20.AutoSize = true;
            radioButton20.ForeColor = Color.Navy;
            radioButton20.Location = new Point(440, 202);
            radioButton20.Name = "radioButton20";
            radioButton20.Size = new Size(51, 19);
            radioButton20.TabIndex = 71;
            radioButton20.TabStop = true;
            radioButton20.Text = "Ligar";
            radioButton20.UseVisualStyleBackColor = true;
            radioButton20.CheckedChanged += radioButton20_CheckedChanged;
            // 
            // radioButton21
            // 
            radioButton21.AutoSize = true;
            radioButton21.ForeColor = Color.Navy;
            radioButton21.Location = new Point(426, 185);
            radioButton21.Name = "radioButton21";
            radioButton21.Size = new Size(67, 19);
            radioButton21.TabIndex = 70;
            radioButton21.TabStop = true;
            radioButton21.Text = "Desligar";
            radioButton21.UseVisualStyleBackColor = true;
            radioButton21.CheckedChanged += radioButton21_CheckedChanged;
            // 
            // radioButton22
            // 
            radioButton22.AutoSize = true;
            radioButton22.ForeColor = Color.Navy;
            radioButton22.Location = new Point(374, 184);
            radioButton22.Name = "radioButton22";
            radioButton22.Size = new Size(51, 19);
            radioButton22.TabIndex = 69;
            radioButton22.TabStop = true;
            radioButton22.Text = "Ligar";
            radioButton22.UseVisualStyleBackColor = true;
            radioButton22.CheckedChanged += radioButton22_CheckedChanged;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI", 15F);
            label20.ForeColor = Color.Navy;
            label20.Location = new Point(339, 151);
            label20.Name = "label20";
            label20.Size = new Size(96, 28);
            label20.TabIndex = 66;
            label20.Text = "COZINHA";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.ForeColor = Color.Navy;
            label19.Location = new Point(41, 351);
            label19.Name = "label19";
            label19.Size = new Size(28, 15);
            label19.TabIndex = 80;
            label19.Text = " Luz";
            // 
            // radioButton23
            // 
            radioButton23.AutoSize = true;
            radioButton23.ForeColor = Color.Navy;
            radioButton23.Location = new Point(129, 351);
            radioButton23.Name = "radioButton23";
            radioButton23.Size = new Size(67, 19);
            radioButton23.TabIndex = 79;
            radioButton23.TabStop = true;
            radioButton23.Text = "Desligar";
            radioButton23.UseVisualStyleBackColor = true;
            radioButton23.CheckedChanged += radioButton23_CheckedChanged;
            // 
            // radioButton24
            // 
            radioButton24.AutoSize = true;
            radioButton24.ForeColor = Color.Navy;
            radioButton24.Location = new Point(77, 350);
            radioButton24.Name = "radioButton24";
            radioButton24.Size = new Size(51, 19);
            radioButton24.TabIndex = 78;
            radioButton24.TabStop = true;
            radioButton24.Text = "Ligar";
            radioButton24.UseVisualStyleBackColor = true;
            radioButton24.CheckedChanged += radioButton24_CheckedChanged;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Segoe UI", 15F);
            label22.ForeColor = Color.Navy;
            label22.Location = new Point(42, 321);
            label22.Name = "label22";
            label22.Size = new Size(107, 28);
            label22.TabIndex = 75;
            label22.Text = "BANHEIRO";
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.NÍVEL_3_removebg_preview_removebg_preview;
            pictureBox5.Location = new Point(386, 227);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(208, 89);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 14;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // FormUsuario
            // 
            ClientSize = new Size(895, 511);
            Controls.Add(label19);
            Controls.Add(radioButton23);
            Controls.Add(radioButton24);
            Controls.Add(label22);
            Controls.Add(label17);
            Controls.Add(label18);
            Controls.Add(radioButton19);
            Controls.Add(radioButton20);
            Controls.Add(radioButton21);
            Controls.Add(radioButton22);
            Controls.Add(label20);
            Controls.Add(label15);
            Controls.Add(radioButton17);
            Controls.Add(radioButton18);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(radioButton13);
            Controls.Add(radioButton14);
            Controls.Add(radioButton15);
            Controls.Add(radioButton16);
            Controls.Add(label16);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(radioButton7);
            Controls.Add(radioButton8);
            Controls.Add(radioButton9);
            Controls.Add(radioButton10);
            Controls.Add(radioButton11);
            Controls.Add(radioButton12);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(radioButton5);
            Controls.Add(radioButton6);
            Controls.Add(radioButton3);
            Controls.Add(radioButton4);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(lblPontos);
            Controls.Add(lblXP);
            Controls.Add(lblNivel);
            Controls.Add(pictureBox1);
            Controls.Add(btnTarefas);
            Controls.Add(btnRecompensas);
            Controls.Add(btnMensagens);
            Controls.Add(btnControleSustentavel);
            Controls.Add(btnHome);
            Name = "FormUsuario";
            Text = "Área do Usuário";
            Load += FormUsuario_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private PictureBox pictureBox1;
        private Label lblNivel;
        private Label lblXP;
        private Label lblPontos;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private Label label1;
        private Label label2;
        private PictureBox pictureBox6;
        private Label label3;
        private Label label4;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private RadioButton radioButton4;
        private RadioButton radioButton5;
        private RadioButton radioButton6;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private RadioButton radioButton7;
        private RadioButton radioButton8;
        private RadioButton radioButton9;
        private RadioButton radioButton10;
        private RadioButton radioButton11;
        private RadioButton radioButton12;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private RadioButton radioButton13;
        private RadioButton radioButton14;
        private RadioButton radioButton15;
        private RadioButton radioButton16;
        private Label label16;
        private Label label15;
        private RadioButton radioButton17;
        private RadioButton radioButton18;
        private Label label17;
        private Label label18;
        private RadioButton radioButton19;
        private RadioButton radioButton20;
        private RadioButton radioButton21;
        private RadioButton radioButton22;
        private Label label20;
        private Label label19;
        private RadioButton radioButton23;
        private RadioButton radioButton24;
        private Label label22;
        private PictureBox pictureBox5;
    }
}
