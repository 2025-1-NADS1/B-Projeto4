﻿using System;
using System.Windows.Forms;

namespace SmartHomeApp
{
    public partial class FormUsuario : Form
    {
        public FormUsuario()
        {
            InitializeComponent();
        }

        private void btnTarefas_Click(object sender, EventArgs e)
        {
            FormTarefas tarefasForm = new FormTarefas();
            tarefasForm.Show();
            this.Hide();
        }

        private void btnRecompensas_Click(object sender, EventArgs e)
        {
            FormRecompensas recompensasForm = new FormRecompensas();
            recompensasForm.Show();
            this.Hide();
        }

        private void btnMensagens_Click(object sender, EventArgs e)
        {
            FormMensagens mensagensForm = new FormMensagens();
            mensagensForm.Show();
            this.Hide();
        }

        private void btnControleSustentavel_Click(object sender, EventArgs e)
        {
            
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            FormUsuario homeForm = new FormUsuario();
            homeForm.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e) // Mensagens Original
        {
            FormMensagens mensagensForm = new FormMensagens();
            mensagensForm.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e) //Tarefas Original
        {
            FormTarefas tarefasForm = new FormTarefas();
            tarefasForm.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e) // Recompensas Original
        {
            FormRecompensas recompensasForm = new FormRecompensas();
            recompensasForm.Show();
            this.Hide();
        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
           FormSimulacao simulacao = new FormSimulacao();
            simulacao.Show();
            this.Hide();
        }

        private void FormUsuario_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Form1 loginForm = new Form1();
            loginForm.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {


            if (radioButton1.Checked)
            {
                MessageBox.Show("A luz do quarto do casal foi ligada!", "Quarto do Casal",
                     MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                MessageBox.Show("A luz do quarto do casal foi desligada!", "Quarto do Casal",
                   MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked)
            {
                MessageBox.Show("A porta do quarto do casal foi destrancada!", "Quarto do Casal",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton6.Checked)
            {
                MessageBox.Show("A porta do quarto do casal foi trancada!", "Quarto do Casal",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked)
            {
                MessageBox.Show("O Ar-condicionado do quarto do casal foi ligado!", "Quarto do Casal",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                MessageBox.Show("O Ar-condicionado do quarto do casal foi desligado!", "Quarto do Casal",
                   MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {

            if (radioButton12.Checked)
            {
                MessageBox.Show("A luz do quarto da criança foi ligada!");
            }
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton11.Checked)
            {
                MessageBox.Show("A luz do quarto da criança foi desligada!");
            }
        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton10.Checked)
            {
                MessageBox.Show("O Ar-condicionado do quarto da criança foi ligado!");
            }
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton9.Checked)
            {
                MessageBox.Show("O Ar-condicionado do quarto da criança foi desligado!");
            }
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton8.Checked)
            {
                MessageBox.Show("A porta do quarto da criança foi trancada!");
            }
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton8.Checked)
            {
                MessageBox.Show("A porta do quarto da criança foi destrancada!");
            }
        }

        private void radioButton24_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton24.Checked)
            {
                MessageBox.Show("A luz do banheiro foi ligada!");
            }
        }

        private void radioButton23_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton23.Checked)
            {
                MessageBox.Show("A luz do banheiro foi desligada!");
            }
        }

        private void radioButton16_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton16.Checked)
            {
                MessageBox.Show("A luz da sala de estar foi ligada!");
            }
        }

        private void radioButton15_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton15.Checked)
            {
                MessageBox.Show("A luz da sala de estar foi desligada!");
            }
        }

        private void radioButton14_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton14.Checked)
            {
                MessageBox.Show("o Ar-condicionado da sala de estar foi ligado!");
            }
        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton13.Checked)
            {
                MessageBox.Show("O Ar-condicionado da sala de estar foi desligado!");
            }
        }

        private void radioButton18_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton18.Checked)
            {
                MessageBox.Show("A porta da sala de estar foi trancada!");
            }
        }

        private void radioButton17_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton17.Checked)
            {
                MessageBox.Show("A porta da sala de estar foi destrancada!");
            }
        }

        private void radioButton22_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton22.Checked)
            {
                MessageBox.Show("A luz da cozinha foi ligada!");
            }
        }

        private void radioButton21_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton21.Checked)
            {
                MessageBox.Show("A luz da cozinha foi desligada!");
            }
        }

        private void radioButton20_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton20.Checked)
            {
                MessageBox.Show("O ar-condicionado da cozinha foi ligado!");
            }
        }

        private void radioButton19_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton19.Checked)
            {
                MessageBox.Show("O ar-condicionado da cozinha foi desligado!");
            }
        }
    }
}
