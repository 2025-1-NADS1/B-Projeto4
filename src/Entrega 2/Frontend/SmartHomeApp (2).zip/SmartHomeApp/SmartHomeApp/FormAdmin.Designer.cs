﻿namespace SmartHomeApp
{
    partial class FormAdmin
    {
        private System.ComponentModel.IContainer components = null;

        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            lblPontos = new Label();
            lblXP = new Label();
            lblNivel = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            pictureBox6 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources._3d_model_of_a_building_with_windows_and_balconies_png_removebg_preview;
            pictureBox1.Location = new Point(282, 52);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(479, 536);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(108, 146);
            label2.Name = "label2";
            label2.Size = new Size(135, 28);
            label2.TabIndex = 16;
            label2.Text = "SUSTENTAVEL";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(108, 118);
            label1.Name = "label1";
            label1.Size = new Size(109, 28);
            label1.TabIndex = 15;
            label1.Text = "CONTROLE";
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.NÍVEL_3_removebg_preview_removebg_preview;
            pictureBox5.Location = new Point(156, 85);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(224, 89);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 17;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.NÍVEL_3__2__removebg_preview1;
            pictureBox4.Location = new Point(765, 229);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(157, 148);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 24;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.NÍVEL_3__4__removebg_preview1;
            pictureBox3.Location = new Point(755, 146);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(175, 119);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 23;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.NÍVEL_3__1__removebg_preview;
            pictureBox2.Location = new Point(752, 60);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(178, 114);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 22;
            pictureBox2.TabStop = false;
            // 
            // lblPontos
            // 
            lblPontos.ForeColor = Color.Navy;
            lblPontos.Location = new Point(533, -13);
            lblPontos.Name = "lblPontos";
            lblPontos.Size = new Size(150, 20);
            lblPontos.TabIndex = 21;
            lblPontos.Text = "Pontos: 0";
            // 
            // lblXP
            // 
            lblXP.ForeColor = Color.Navy;
            lblXP.Location = new Point(533, -28);
            lblXP.Name = "lblXP";
            lblXP.Size = new Size(150, 20);
            lblXP.TabIndex = 20;
            lblXP.Text = "XP: 0 / 100";
            // 
            // lblNivel
            // 
            lblNivel.Font = new Font("Segoe UI", 20F);
            lblNivel.ForeColor = Color.Navy;
            lblNivel.Location = new Point(524, -63);
            lblNivel.Name = "lblNivel";
            lblNivel.Size = new Size(221, 70);
            lblNivel.TabIndex = 19;
            lblNivel.Text = "Nível: 1";
            // 
            // label3
            // 
            label3.Font = new Font("Segoe UI", 20F);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(765, 9);
            label3.Name = "label3";
            label3.Size = new Size(221, 70);
            label3.TabIndex = 25;
            label3.Text = "Nível: 1";
            // 
            // label4
            // 
            label4.ForeColor = Color.Navy;
            label4.Location = new Point(772, 39);
            label4.Name = "label4";
            label4.Size = new Size(150, 20);
            label4.TabIndex = 26;
            label4.Text = "XP: 0 / 100";
            // 
            // label5
            // 
            label5.ForeColor = Color.Navy;
            label5.Location = new Point(772, 52);
            label5.Name = "label5";
            label5.Size = new Size(150, 20);
            label5.TabIndex = 27;
            label5.Text = "Pontos: 0";
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.LOGIN__59_4_x_42_cm___2__removebg_preview;
            pictureBox6.Location = new Point(762, 325);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(172, 99);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 28;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // FormAdmin
            // 
            ClientSize = new Size(888, 527);
            Controls.Add(pictureBox6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(lblPontos);
            Controls.Add(lblXP);
            Controls.Add(lblNivel);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox1);
            Name = "FormAdmin";
            Text = "Área do Administrador";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private PictureBox pictureBox1;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private Label lblPontos;
        private Label lblXP;
        private Label lblNivel;
        private Label label3;
        private Label label4;
        private Label label5;
        private PictureBox pictureBox6;
    }
}
