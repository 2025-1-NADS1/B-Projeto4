﻿namespace SmartHomeApp
{
    partial class FormSimulacao
    {
        private System.ComponentModel.IContainer components = null;
        private Label lblLuz;
        private Label lblAgua;
        private Label lblCO2;
        private Button btnAtualizar;
        private Button btnHome;

        private void InitializeComponent()
        {
            lblLuz = new Label();
            lblAgua = new Label();
            lblCO2 = new Label();
            btnAtualizar = new Button();
            btnHome = new Button();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            lblPontos = new Label();
            lblXP = new Label();
            lblNivel = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            label7 = new Label();
            label8 = new Label();
            agualbl = new Label();
            luzlbl = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            SuspendLayout();
            // 
            // lblLuz
            // 
            lblLuz.Location = new Point(30, 30);
            lblLuz.Name = "lblLuz";
            lblLuz.Size = new Size(250, 20);
            lblLuz.TabIndex = 0;
            // 
            // lblAgua
            // 
            lblAgua.Location = new Point(30, 60);
            lblAgua.Name = "lblAgua";
            lblAgua.Size = new Size(250, 20);
            lblAgua.TabIndex = 1;
            // 
            // lblCO2
            // 
            lblCO2.Location = new Point(30, 90);
            lblCO2.Name = "lblCO2";
            lblCO2.Size = new Size(250, 20);
            lblCO2.TabIndex = 2;
            // 
            // btnAtualizar
            // 
            btnAtualizar.Location = new Point(-7, 524);
            btnAtualizar.Name = "btnAtualizar";
            btnAtualizar.Size = new Size(10, 10);
            btnAtualizar.TabIndex = 3;
            btnAtualizar.Text = "🔄 Atualizar";
            btnAtualizar.Click += btnAtualizar_Click;
            // 
            // btnHome
            // 
            btnHome.Location = new Point(883, 524);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(10, 10);
            btnHome.TabIndex = 4;
            btnHome.Text = "🏠";
            btnHome.Click += btnHome_Click;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.Navy;
            textBox2.Font = new Font("Segoe UI", 20F);
            textBox2.ForeColor = Color.White;
            textBox2.Location = new Point(234, 197);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(115, 43);
            textBox2.TabIndex = 6;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.Navy;
            textBox1.Font = new Font("Segoe UI", 20F);
            textBox1.ForeColor = Color.White;
            textBox1.Location = new Point(234, 137);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(115, 43);
            textBox1.TabIndex = 7;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 22F);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(176, 197);
            label2.Name = "label2";
            label2.Size = new Size(52, 41);
            label2.TabIndex = 9;
            label2.Text = "R$";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 22F);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(176, 137);
            label1.Name = "label1";
            label1.Size = new Size(52, 41);
            label1.TabIndex = 10;
            label1.Text = "R$";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 30F);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(69, 60);
            label3.Name = "label3";
            label3.Size = new Size(309, 45);
            label3.TabIndex = 11;
            label3.Text = "Consulta Mensal";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 13F);
            label4.ForeColor = Color.Navy;
            label4.Location = new Point(30, 105);
            label4.Name = "label4";
            label4.Size = new Size(381, 21);
            label4.TabIndex = 12;
            label4.Text = "Digite os valores de suas contas do mês atual:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 25F);
            label5.ForeColor = Color.Navy;
            label5.Location = new Point(92, 140);
            label5.Name = "label5";
            label5.Size = new Size(71, 39);
            label5.TabIndex = 13;
            label5.Text = "Luz";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 25F);
            label6.ForeColor = Color.Navy;
            label6.Location = new Point(85, 197);
            label6.Name = "label6";
            label6.Size = new Size(95, 39);
            label6.TabIndex = 14;
            label6.Text = "Água";
            // 
            // lblPontos
            // 
            lblPontos.ForeColor = Color.Navy;
            lblPontos.Location = new Point(788, 59);
            lblPontos.Name = "lblPontos";
            lblPontos.Size = new Size(64, 20);
            lblPontos.TabIndex = 17;
            lblPontos.Text = "Pontos: 0";
            // 
            // lblXP
            // 
            lblXP.ForeColor = Color.Navy;
            lblXP.Location = new Point(788, 44);
            lblXP.Name = "lblXP";
            lblXP.Size = new Size(64, 20);
            lblXP.TabIndex = 16;
            lblXP.Text = "XP: 0 / 100";
            // 
            // lblNivel
            // 
            lblNivel.Font = new Font("Segoe UI", 20F);
            lblNivel.ForeColor = Color.Navy;
            lblNivel.Location = new Point(779, 9);
            lblNivel.Name = "lblNivel";
            lblNivel.Size = new Size(135, 70);
            lblNivel.TabIndex = 15;
            lblNivel.Text = "Nível: 1";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.NÍVEL_3__8__removebg_preview;
            pictureBox1.Location = new Point(779, 64);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(149, 112);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 18;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.NÍVEL_3__1__removebg_preview;
            pictureBox2.Location = new Point(767, 149);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(178, 114);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 19;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.NÍVEL_3__4__removebg_preview1;
            pictureBox3.Location = new Point(769, 230);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(175, 119);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 20;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.NÍVEL_3__2__removebg_preview1;
            pictureBox4.Location = new Point(777, 312);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(157, 148);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 21;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.NÍVEL_3__5__removebg_preview;
            pictureBox5.Location = new Point(355, 232);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(573, 334);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 22;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.LOGIN__59_4_x_42_cm___7_;
            pictureBox6.Location = new Point(66, 181);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(317, 221);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 23;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10F);
            label7.ForeColor = Color.Navy;
            label7.Location = new Point(30, 337);
            label7.Name = "label7";
            label7.Size = new Size(0, 19);
            label7.TabIndex = 24;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 30F);
            label8.ForeColor = Color.Navy;
            label8.Location = new Point(369, 6);
            label8.Name = "label8";
            label8.Size = new Size(112, 54);
            label8.TabIndex = 25;
            label8.Text = "Maio";
            // 
            // agualbl
            // 
            agualbl.AutoSize = true;
            agualbl.Font = new Font("Segoe UI", 10F);
            agualbl.ForeColor = Color.Navy;
            agualbl.Location = new Point(30, 367);
            agualbl.Name = "agualbl";
            agualbl.Size = new Size(0, 19);
            agualbl.TabIndex = 26;
            // 
            // luzlbl
            // 
            luzlbl.AutoSize = true;
            luzlbl.Font = new Font("Segoe UI", 10F);
            luzlbl.ForeColor = Color.Navy;
            luzlbl.Location = new Point(30, 400);
            luzlbl.Name = "luzlbl";
            luzlbl.Size = new Size(0, 19);
            luzlbl.TabIndex = 27;
            // 
            // FormSimulacao
            // 
            ClientSize = new Size(890, 532);
            Controls.Add(luzlbl);
            Controls.Add(agualbl);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(lblPontos);
            Controls.Add(lblXP);
            Controls.Add(lblNivel);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(textBox2);
            Controls.Add(lblLuz);
            Controls.Add(lblAgua);
            Controls.Add(lblCO2);
            Controls.Add(btnAtualizar);
            Controls.Add(btnHome);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox6);
            Name = "FormSimulacao";
            Text = "Simulação de Consumo";
            Load += FormSimulacao_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private TextBox textBox2;
        private TextBox textBox1;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label lblPontos;
        private Label lblXP;
        private Label lblNivel;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private Label label7;
        private Label label8;
        private Label agualbl;
        private Label luzlbl;
    }
}
