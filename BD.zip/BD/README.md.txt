README - Sistema de Casa Inteligente

Visão Geral
Este projeto consiste na modelagem conceitual de um banco de dados para uma casa inteligente com 2 moradores, contemplando 5 ambientes monitorados por sensores. O sistema permite gerenciar dispositivos IoT, registrar eventos e monitorar condições ambientais.

Modelagem do Banco de Dados

 Principais Entidades: 

1. MORADOR - Cadastro dos residentes
2. COMODO - Ambientes da casa (quartos, sala, cozinha, piscina)
3. SENSOR - Dispositivos de monitoramento
4. DISPOSITIVO - Aparelhos inteligentes
5. EVENTO - Registros de atividades e alertas

 Esquema Relacional SQl

Exemplo das tabelas principais:

MORADOR(ID_Morador, Nome, DataNascimento, Telefone, Tipo)
COMODO(ID_Comodo, Nome, Tipo, Area_m2, UltimaManutencao)
SENSOR(ID_Sensor, ID_Comodo, Tipo, Modelo, DataInstalacao, Status)